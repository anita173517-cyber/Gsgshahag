package com.harindra.tvlauncher

import android.content.pm.PackageManager
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val pm: PackageManager,
    private val prefs: PrefsManager,
    private val onAppClick: (AppItem) -> Unit,
    private val onAppLongClick: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.AppViewHolder>() {

    private val items = mutableListOf<AppItem>()

    fun submitList(newItems: List<AppItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_card, parent, false)
        return AppViewHolder(view)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class AppViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivIcon: ImageView = itemView.findViewById(R.id.ivAppIcon)
        private val tvName: TextView = itemView.findViewById(R.id.tvAppName)
        private val tvBadgeTop: TextView = itemView.findViewById(R.id.tvBadgeTop)

        fun bind(item: AppItem) {
            tvName.text = item.label
            IconCache.loadAppIcon(pm, item.packageName, ivIcon)

            val speedDigit = prefs.findSpeedDialDigit("app:${item.packageName}")
            val isLocked = item.packageName in prefs.getLockedPackages()
            when {
                isLocked && speedDigit != null -> {
                    tvBadgeTop.visibility = View.VISIBLE
                    tvBadgeTop.text = "🔒 #$speedDigit"
                }
                isLocked -> {
                    tvBadgeTop.visibility = View.VISIBLE
                    tvBadgeTop.text = "🔒"
                }
                speedDigit != null -> {
                    tvBadgeTop.visibility = View.VISIBLE
                    tvBadgeTop.text = "#$speedDigit"
                }
                else -> tvBadgeTop.visibility = View.GONE
            }

            itemView.setOnClickListener { onAppClick(item) }
            itemView.setOnLongClickListener {
                onAppLongClick(item)
                true
            }

            itemView.setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_MENU) {
                    onAppLongClick(item)
                    true
                } else {
                    false
                }
            }

            itemView.setOnFocusChangeListener { v, hasFocus ->
                if (prefs.isUltraLiteMode) {
                    v.scaleX = if (hasFocus) 1.04f else 1.0f
                    v.scaleY = if (hasFocus) 1.04f else 1.0f
                    v.elevation = if (hasFocus) 8f else 0f
                } else {
                    val scale = if (hasFocus) 1.08f else 1.0f
                    v.animate().scaleX(scale).scaleY(scale).setDuration(105).start()
                    v.elevation = if (hasFocus) 12f else 0f
                }
            }
        }
    }
}
