package com.harindra.tvlauncher

import android.app.ActivityManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class AmbientActivity : AppCompatActivity() {

    private lateinit var tvTime: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvStats: TextView
    private lateinit var clockBox: LinearLayout
    private lateinit var prefs: PrefsManager

    private val handler = Handler(Looper.getMainLooper())
    private val tickRunnable = object : Runnable {
        override fun run() {
            updateClock()
            clockBox.translationX = Random.nextInt(-32, 33).toFloat()
            clockBox.translationY = Random.nextInt(-22, 23).toFloat()
            handler.postDelayed(this, 30_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ambient)
        prefs = PrefsManager(this)
        tvTime = findViewById(R.id.tvAmbientTime)
        tvDate = findViewById(R.id.tvAmbientDate)
        tvStats = findViewById(R.id.tvAmbientStats)
        clockBox = findViewById(R.id.ambientClockBox)

        findViewById<View>(R.id.ambientRoot).setOnClickListener { finish() }
        updateClock()
    }

    private fun updateClock() {
        val now = Date()
        val timeFmt = if (prefs.is24HourClock) "HH:mm" else "hh:mm a"
        tvTime.text = SimpleDateFormat(timeFmt, Locale.getDefault()).format(now)
        tvDate.text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now)

        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val freeMb = mi.availMem / (1024L * 1024L)
        tvStats.text = "UltraTV Pro • Free RAM: ${freeMb}MB • OLED Burn-In Safe"
    }

    override fun onResume() {
        super.onResume()
        handler.post(tickRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tickRunnable)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        finish()
        return true
    }
}
